function [corval,pval] = labelPropContCV(labels, kernel, nFolds, pp)
% function [areas, aup] = labelPropCV(labels, kernel, nFolds, pp)


NN = length(labels);


offset = 0;

for ii = 1:nFolds
    lastElem = min(NN, offset+floor(NN/nFolds));
    ix = pp(offset+1:lastElem);
    offset = lastElem;
    myLabels = labels;
    iz = setdiff(pp,ix);
    myLabels(ix) = mean(labels(iz));
    
    res = getScoreVectorCGBase(myLabels,kernel);
    
    [corval(ii),pval(ii)] = corr(res(ix),labels(ix));
    
end

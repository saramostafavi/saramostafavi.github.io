function [areas, aup,pvalue,ResCV,LabelsCV,testIx] = labelPropCVPvalue(labels, kernel, nFolds, pp)
% function [areas, aup] = labelPropCV(labels, kernel, nFolds, pp)


NN = length(labels);


offset = 0;

for ii = 1:nFolds
    lastElem = min(NN, offset+floor(NN/nFolds));
    ix = pp(offset+1:lastElem);
    offset = lastElem;
    myLabels = labels;
    myLabels(ix) = 0;
    
    res = getScoreVectorCGBase(myLabels,kernel);
    
    
    areas(ii) = calcROCarea(res(ix), double(labels(ix)>0));
    aup(ii) = calcAUP_v2(res(ix),double(labels(ix)>0));
    ResCV{ii} = res;
    LabelsCV{ii} = myLabels;
    testIx{ii} = ix;
    
    ip = ix(find(labels(ix)==1));
    in = setdiff(ix,ip);
    try
        pvalue(ii) = ranksum(res(ip),res(in));
    catch
        pvalue(ii) = NaN;
    end
end

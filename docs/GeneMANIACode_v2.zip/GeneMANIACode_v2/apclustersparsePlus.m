%APCLUSTERSPARSE Affinity Propagation Clustering (Frey/Dueck, Science 2007)
% [idx,netsim,dpsim,expref]=APCLUSTERSPARSE(s,p) clusters data,
% using a set of real-valued pairwise data point similarities as input.
% Clusters are each represented by a cluster center data point (the
% "exemplar"). The method is iterative and searches for clusters so as 
% to maximize an objective function, called net similarity.
% 
% For N data points, there are potentially N^2-N pairwise similarities; 
% this can be input as an N-by-N matrix 's', where s(i,k) is the 
% similarity of point i to point k (s(i,k) needn�t equal s(k,i)).  In 
% fact, only a smaller number of relevant similarities are needed; if 
% only M similarity values are known (M < N^2-N) they can be input as 
% an M-by-3 matrix with each row being an (i,j,s(i,j)) triple.
% 
% APCLUSTERSPARSE automatically determines the number of clusters
% based on the input preference 'p', a real-valued N-vector. p(i) indicates
% the preference that data point i be chosen as an exemplar. Often a good 
% choice is to set all preferences to median(s); the number of clusters ident-
% ified can be adjusted by changing this value accordingly. If 'p'  is a scalar,
% APCLUSTERSPARSE assumes all preferences are that shared value.
% 
% The clustering solution is returned in idx. idx(j) is the index of 
% the exemplar for data point j; idx(j)==j indicates data point j 
% is itself an exemplar. The sum of the similarities of the data points to 
% their exemplars is returned as dpsim, the sum of the preferences of 
% the identified exemplars is returned in expref and the net similarity 
% objective function returned is their sum, i.e. netsim=dpsim+expref.
% 
% 	[ ... ]=apcluster(s,p,'NAME',VALUE,...) allows you to specify 
% 	  optional parameter name/value pairs as follows:
% 
%   'maxits'     maximum number of iterations (default: 500)
%   'convits'    if the estimated exemplars stay fixed for convits 
%          iterations, APCLUSTERSPARSE terminates early (default: 50)
%   'dampfact'   update equation damping level in [0.5, 1).  Higher 
%        values correspond to heavy damping, which may be needed 
%        if oscillations occur.
%   'plot'       (no value needed) Plots netsim after each iteration
%   'details'    (no value needed) Outputs iteration-by-iteration 
%      details (greater memory requirements)
%   'nonoise'    (no value needed) APCLUSTERSPARSE adds a small amount
%      of noise to 's' to prevent degenerate cases; this disables that.
% 
% Copyright (c) B.J. Frey & D. Dueck (2006). This software may be 
% freely used and distributed for non-commercial purposes.
function [idx,netsim,expref,dpsim] = apclustersparsePlus(s,p,varargin)
start = clock;
if ~issparse(s) & size(s,1)==size(s,2),% full matrix
	sij=s(:); [I,J]=size(s); sij(sub2ind([I J],1:I,1:I))=p(:)';
else
	if size(s,2)==3, si=s(:,1); sj=s(:,2); sij=s(:,3);
	elseif issparse(s), [si,sj,sij]=find(s);
	end;
	I=max(si); J=max(sj);
	ii=find(si==sj); if isempty(ii), si=[si; (1:max(I,J))']; sj=[sj; (1:max(I,J))']; ii=find(si==sj); end;
	[junk,order]=sort(si(ii)); sij(ii(order))=p;
	if isempty(find(si<sj,1,'first')) || isempty(find(si>sj,1,'first')), warning('s(i,j) does not imply s(j,i) -- check if all desired (i,j) pairs are included'); end;
end;

N=length(sij);

options = struct('cbSize',40,'lambda',0.9,'minimum_iterations',1,'converge_iterations',50,'maximum_iterations',500,'details',0,'nonoise',0);
switch(computer),
	case {'PCWIN'}, options.cbSize=40;
	case {'GLNXA64'}, options.cbSize=48;
	case {'GLNX86'}, options.cbSize=36;
	otherwise, error(sprintf('Affinity Propagation not supported on %s platform [yet]',computer));
end;
while numel(varargin),
	switch(varargin{1}),
		case {'details','det'}
			options.details=1;
			varargin(1)=[];
		case {'nodetails','nodet'}
			options.details=0;
			varargin(1)=[];
		case {'convits','cnvits','conv','cnv'}
			options.converge_iterations=varargin{2};
			varargin(1:2)=[];
		case {'dampfact','damping','dmpfact','lambda'}
			options.lambda=varargin{2};
			varargin(1:2)=[];
		case {'maxiter','mxiter','maxits','mxits'}
			options.maximum_iterations=varargin{2};
			varargin(1:2)=[];
		otherwise,
			varargin(1)=[];
	end;
end;

if exist('si','var') & exist('sj','var'),
	if I<2^16-1, si=uint16(si-1); sj=uint16(sj-1); else si=uint32(si-1); sj=uint32(sj-1); end;
end;

if options.details,
	idx = -ones(I,options.maximum_iterations,'int32');
	netsim = zeros(1,options.maximum_iterations);
else
	idx = -ones(I,1,'int32');
	netsim = 0;
end;

if exist('si','var') & exist('sj','var'),
	ret = apclustermex(sij,si,sj,N,idx,netsim,options);
else
	ret = apclustermex(sij,N,idx,netsim,options);
end;
if ret<0, error(sprintf('apclustermex returned error code %d',ret)); end;

T = length(netsim(netsim~=0));
netsim = netsim(1:T);
idx = idx(:,1:T)+1;
expref = netsim; K = netsim;
for t=1:T,
	exs = unique(idx(:,t)); exs=exs(exs>0); K(t)=length(exs);
	if numel(p)==1, expref(t)=p*length(exs); else expref(t)=sum(p(exs)); end;
end;
dpsim = netsim - expref;
finish = clock;

if options.details,
    fprintf('\nNumber of exemplars identified: %d  (for %d data points)\n',length(exs),I);
    fprintf('Fitness (net similarity): %f\n',netsim(end));
    fprintf('  Similarities of data points to exemplars: %f\n',dpsim(end));
    fprintf('  Preferences of selected exemplars: %f\n',expref(end));
    fprintf('Number of iterations: %d\n',T);
	fprintf('Elapsed time: %f sec\n\n',etime(finish,start));
end;

return
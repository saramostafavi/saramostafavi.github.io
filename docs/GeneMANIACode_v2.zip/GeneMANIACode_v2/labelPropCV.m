function [areas, aup,ResCV,LabelsCV,testIx] = labelPropCV(labels, kernel, nFolds, pp)
% function [areas, aup] = labelPropCV(labels, kernel, nFolds, pp)
% label vector: +1 for positive nodes, 0 for other points. size nx1
% kernel: a symmetric similarity matrix -- diagonals must be zero. size nxn
% nFolds: number of crossvalidation folds
% pp a permutation vector of length n (n is the number o nodes in kernel) used for crossvalidations

NN = length(labels);


offset = 0;

for ii = 1:nFolds
    lastElem = min(NN, offset+floor(NN/nFolds));
    ix = pp(offset+1:lastElem);
    offset = lastElem;
    myLabels = labels;
    myLabels(ix) = 0;
    
    res = getScoreVectorCGBase(myLabels,kernel);
    
    
    areas(ii) = calcROCarea(res(ix), double(labels(ix)>0));
    aup(ii) = calcAUP_v2(res(ix),double(labels(ix)>0));
    ResCV{ii} = res;
    LabelsCV{ii} = myLabels;
    testIx{ii} = ix;
end
